# Sistema Académico MVC — Programación II

## IntelliJ IDEA
1. Descomprime el ZIP.
2. Abre IntelliJ IDEA > File > Open y selecciona la carpeta SistemaAcademico (o pom.xml).
3. Importa el proyecto Maven y selecciona JDK 17 o superior en Project Structure.
4. Abre src/main/java/com/universidad/principal/Aplicacion.java y ejecuta main con el botón verde.
5. Usa la carpeta raíz del proyecto como Working directory en Run > Edit Configurations.

El CSV se crea en datos/estudiantes.csv al registrar el primer estudiante. No requiere dependencias externas. Maven puede necesitar internet para descargar su plugin de compilación.

## Prueba
Registra código 101, Ana López, nota 85; registra 102, Carlos Pérez, nota 45. Lista, busca, actualiza 102 a 68 y reinicia para comprobar persistencia. Elimina un registro con confirmación S.

## Diseño
Modelo: Estudiante; negocio: ServicioEstudiantes; persistencia: RepositorioEstudiantesCSV; vista: VistaEstudiante; controlador: ControladorEstudiante; entrada: Aplicacion.

Nota mínima de aprobación: 51. CSV UTF-8 simplificado: los nombres no admiten comas, comillas ni saltos de línea. Aplicación local de un solo usuario; no soporta escrituras concurrentes.
