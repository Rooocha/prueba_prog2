package com.universidad.controlador;
import com.universidad.modelo.Estudiante;
import com.universidad.servicio.ServicioEstudiantes;
import com.universidad.vista.VistaEstudiante;
import java.io.IOException;
import java.util.*;

public class ControladorEstudiante {
    private final ServicioEstudiantes servicio;
    private final VistaEstudiante vista;
    public ControladorEstudiante(ServicioEstudiantes servicio, VistaEstudiante vista) { this.servicio = servicio; this.vista = vista; }
    public void iniciar() {
        while (true) {
            try {
                switch (vista.mostrarMenu()) {
                    case 1 -> registrar();
                    case 2 -> vista.mostrarEstudiantes(servicio.listar());
                    case 3 -> buscar();
                    case 4 -> actualizar();
                    case 5 -> eliminar();
                    case 6 -> { vista.mostrarMensaje("Programa finalizado."); return; }
                    default -> vista.mostrarMensaje("Opción no válida.");
                }
            } catch (NumberFormatException e) { vista.mostrarMensaje("Error: Ingrese un número válido."); }
            catch (IllegalArgumentException e) { vista.mostrarMensaje("Error de validación: " + e.getMessage()); }
            catch (IOException e) { vista.mostrarMensaje("Error de archivo: " + e.getMessage()); }
            catch (NoSuchElementException e) { vista.mostrarMensaje("Entrada finalizada."); return; }
        }
    }
    private void registrar() throws IOException {
        Estudiante e = vista.leerEstudiante(); servicio.registrar(e);
        vista.mostrarMensaje("Estudiante registrado correctamente."); vista.mostrarEstudiante(e);
    }
    private void buscar() throws IOException {
        servicio.buscar(vista.leerCodigo()).ifPresentOrElse(vista::mostrarEstudiante, () -> vista.mostrarMensaje("Estudiante no encontrado."));
    }
    private void actualizar() throws IOException {
        int codigo = vista.leerCodigo(); Optional<Estudiante> actual = servicio.buscar(codigo);
        if (actual.isEmpty()) { vista.mostrarMensaje("Estudiante no encontrado."); return; }
        vista.mostrarEstudiante(actual.get()); vista.mostrarMensaje("Ingrese los nuevos datos:");
        Estudiante e = vista.leerDatos(codigo);
        if (servicio.actualizar(e)) { vista.mostrarMensaje("Estudiante actualizado correctamente."); vista.mostrarEstudiante(e); }
        else vista.mostrarMensaje("No se pudo actualizar.");
    }
    private void eliminar() throws IOException {
        int codigo = vista.leerCodigo(); Optional<Estudiante> actual = servicio.buscar(codigo);
        if (actual.isEmpty()) { vista.mostrarMensaje("Estudiante no encontrado."); return; }
        vista.mostrarEstudiante(actual.get());
        if (!vista.confirmarEliminacion()) { vista.mostrarMensaje("Eliminación cancelada."); return; }
        vista.mostrarMensaje(servicio.eliminar(codigo) ? "Estudiante eliminado correctamente." : "No se pudo eliminar.");
    }
}
