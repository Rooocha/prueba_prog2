package com.universidad.modelo;

public class Estudiante {
    private final int codigo;
    private final String nombre;
    private final double nota;
    public Estudiante(int codigo, String nombre, double nota) {
        if (codigo <= 0) throw new IllegalArgumentException("El código debe ser positivo.");
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Nombre obligatorio.");
        if (nombre.contains(",") || nombre.contains("\"") || nombre.contains("\n") || nombre.contains("\r"))
            throw new IllegalArgumentException("El nombre no admite comas, comillas ni saltos de línea.");
        if (!Double.isFinite(nota) || nota < 0 || nota > 100)
            throw new IllegalArgumentException("La nota debe estar entre 0 y 100.");
        this.codigo = codigo; this.nombre = nombre.trim(); this.nota = nota;
    }
    public int getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getNota() { return nota; }
    public String getCondicion() { return nota >= 51 ? "APROBADO" : "REPROBADO"; }
    @Override public String toString() { return codigo + " | " + nombre + " | " + nota + " | " + getCondicion(); }
}
