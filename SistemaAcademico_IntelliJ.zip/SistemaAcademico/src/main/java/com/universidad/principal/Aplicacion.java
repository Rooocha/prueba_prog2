package com.universidad.principal;
import com.universidad.repositorio.RepositorioEstudiantesCSV;
import com.universidad.servicio.ServicioEstudiantes;
import com.universidad.vista.VistaEstudiante;
import com.universidad.controlador.ControladorEstudiante;

public class Aplicacion {
    public static void main(String[] args) {
        var repositorio = new RepositorioEstudiantesCSV("datos/estudiantes.csv");
        var servicio = new ServicioEstudiantes(repositorio);
        try (VistaEstudiante vista = new VistaEstudiante()) {
            new ControladorEstudiante(servicio, vista).iniciar();
        }
    }
}
