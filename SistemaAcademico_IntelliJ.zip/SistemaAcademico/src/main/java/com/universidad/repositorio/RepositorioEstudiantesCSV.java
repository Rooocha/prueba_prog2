package com.universidad.repositorio;
import com.universidad.modelo.Estudiante;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class RepositorioEstudiantesCSV {
    private final Path ruta;
    private static final String CABECERA = "codigo,nombre,nota,condicion";
    public RepositorioEstudiantesCSV(String archivo) { ruta = Path.of(archivo).toAbsolutePath().normalize(); }
    public List<Estudiante> listar() throws IOException {
        List<Estudiante> lista = new ArrayList<>();
        Set<Integer> codigos = new HashSet<>();
        if (Files.notExists(ruta)) return lista;
        try (BufferedReader lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            if (!CABECERA.equals(lector.readLine())) throw new IOException("Cabecera CSV inválida.");
            String linea; int n = 1;
            while ((linea = lector.readLine()) != null) {
                n++;
                if (linea.isBlank()) continue;
                String[] d = linea.split(",", -1);
                try {
                    if (d.length != 4) throw new IllegalArgumentException("Cantidad de campos incorrecta.");
                    Estudiante e = new Estudiante(Integer.parseInt(d[0]), d[1], Double.parseDouble(d[2]));
                    if (!codigos.add(e.getCodigo())) throw new IllegalArgumentException("Código duplicado.");
                    if (!e.getCondicion().equals(d[3])) throw new IllegalArgumentException("Condición inconsistente.");
                    lista.add(e);
                } catch (IllegalArgumentException ex) { throw new IOException("Línea " + n + ": " + ex.getMessage(), ex); }
            }
        }
        return lista;
    }
    public void guardarTodos(List<Estudiante> estudiantes) throws IOException {
        Files.createDirectories(ruta.getParent());
        Path temporal = Files.createTempFile(ruta.getParent(), "estudiantes-", ".tmp");
        try {
            try (BufferedWriter escritor = Files.newBufferedWriter(temporal, StandardCharsets.UTF_8)) {
                escritor.write(CABECERA); escritor.newLine();
                for (Estudiante e : estudiantes) {
                    escritor.write(e.getCodigo() + "," + e.getNombre() + "," + e.getNota() + "," + e.getCondicion());
                    escritor.newLine();
                }
            }
            try { Files.move(temporal, ruta, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporal, ruta, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temporal); }
    }
}
