package com.universidad.servicio;
import com.universidad.modelo.Estudiante;
import com.universidad.repositorio.RepositorioEstudiantesCSV;
import java.io.IOException;
import java.util.*;

public class ServicioEstudiantes {
    private final RepositorioEstudiantesCSV repositorio;
    public ServicioEstudiantes(RepositorioEstudiantesCSV repositorio) { this.repositorio = repositorio; }
    public void registrar(Estudiante e) throws IOException {
        List<Estudiante> lista = repositorio.listar();
        if (lista.stream().anyMatch(a -> a.getCodigo() == e.getCodigo()))
            throw new IllegalArgumentException("Ya existe un estudiante con ese código.");
        lista.add(e); repositorio.guardarTodos(lista);
    }
    public List<Estudiante> listar() throws IOException { return repositorio.listar(); }
    public Optional<Estudiante> buscar(int codigo) throws IOException {
        return listar().stream().filter(e -> e.getCodigo() == codigo).findFirst();
    }
    public boolean actualizar(Estudiante e) throws IOException {
        List<Estudiante> lista = listar();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo() == e.getCodigo()) {
                lista.set(i, e); repositorio.guardarTodos(lista); return true;
            }
        }
        return false;
    }
    public boolean eliminar(int codigo) throws IOException {
        List<Estudiante> lista = listar();
        boolean eliminado = lista.removeIf(e -> e.getCodigo() == codigo);
        if (eliminado) repositorio.guardarTodos(lista);
        return eliminado;
    }
}
