package com.universidad.vista;
import com.universidad.modelo.Estudiante;
import java.util.*;

public class VistaEstudiante implements AutoCloseable {
    private final Scanner teclado = new Scanner(System.in);
    public int mostrarMenu() {
        System.out.println("\n=== SISTEMA ACADÉMICO ===\n1. Registrar\n2. Listar\n3. Buscar\n4. Actualizar\n5. Eliminar\n6. Salir");
        System.out.print("Seleccione una opción: ");
        return Integer.parseInt(teclado.nextLine().trim());
    }
    public int leerCodigo() {
        System.out.print("Código del estudiante: ");
        int codigo = Integer.parseInt(teclado.nextLine().trim());
        if (codigo <= 0) throw new IllegalArgumentException("El código debe ser positivo.");
        return codigo;
    }
    public Estudiante leerEstudiante() { return leerDatos(leerCodigo()); }
    public Estudiante leerDatos(int codigo) {
        System.out.print("Nombre completo: "); String nombre = teclado.nextLine();
        System.out.print("Calificación: "); double nota = Double.parseDouble(teclado.nextLine().trim());
        return new Estudiante(codigo, nombre, nota);
    }
    public void mostrarEstudiante(Estudiante e) { System.out.println(e); }
    public void mostrarEstudiantes(List<Estudiante> lista) {
        if (lista.isEmpty()) { mostrarMensaje("No existen estudiantes registrados."); return; }
        System.out.printf("%-10s %-25s %-10s %-12s%n", "CÓDIGO", "NOMBRE", "NOTA", "CONDICIÓN");
        for (Estudiante e : lista) System.out.printf("%-10d %-25s %-10.2f %-12s%n", e.getCodigo(), e.getNombre(), e.getNota(), e.getCondicion());
    }
    public boolean confirmarEliminacion() {
        System.out.print("¿Confirma la eliminación? (S/N): "); return teclado.nextLine().trim().equalsIgnoreCase("S");
    }
    public void mostrarMensaje(String mensaje) { System.out.println(mensaje); }
    @Override public void close() { teclado.close(); }
}
